## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  warning   = FALSE,
  message   = FALSE
)
library(TernTables)
options(tibble.width = Inf)  # show all columns in printed tibbles
# Output directory for exported .docx files.
# Override by setting options(TernTables.vignette_outdir = "/your/path") before rendering.
out_dir <- getOption("TernTables.vignette_outdir", default = tempdir())

## ----load-data----------------------------------------------------------------
data(tern_colon)

## ----ternP-run, eval = FALSE--------------------------------------------------
# # Load a messy CSV shipped with the package
# path <- system.file("extdata/csv", "tern_colon_messy.csv",
#                     package = "TernTables")
# raw    <- readr::read_csv(path, show_col_types = FALSE)
# result <- ternP(raw)
# # The print method fires automatically, summarising every transformation applied.

## ----ternP-access, eval = FALSE-----------------------------------------------
# result$clean_data    # Cleaned, analysis-ready tibble
# result$sparse_rows   # Rows with >50% NA (retained, not removed — review these)
# result$feedback      # Named list; NULL elements mean no action was taken

## ----ternP-doc, eval = FALSE--------------------------------------------------
# write_cleaning_doc(result,
#                    filename = file.path(out_dir, "cleaning_summary.docx"))

## ----ternP-handoff, eval = FALSE----------------------------------------------
# tbl <- ternG(result$clean_data,
#              exclude_vars = c("ID"),
#              group_var    = "Recurrence")

## ----ternD-example, results = "hide"------------------------------------------
tbl_descriptive <- ternD(
  data             = tern_colon,
  exclude_vars     = c("ID"),
  output_docx      = file.path(out_dir, "Tern_descriptive.docx"),
  methods_filename = file.path(out_dir, "TernTables_methods.docx"),
  open_doc         = FALSE,
  category_start = c(
    "Patient Demographics"  = "Age (yr)",
    "Surgical Findings"     = "Colonic Obstruction",
    "Tumor Characteristics" = "Positive Lymph Nodes (n)",
    "Outcomes"              = "Recurrence"
  )
)
tbl_descriptive

## ----ternD-figure, echo=FALSE, fig.align="center", out.width="45%"------------
knitr::include_graphics("figures/tern_descriptive.png")

## ----ternG-2group, results = "hide"-------------------------------------------
tbl_2group <- ternG(
  data             = tern_colon,
  exclude_vars     = c("ID"),
  group_var        = "Recurrence",
  output_docx      = file.path(out_dir, "Tern_2_group.docx"),
  methods_filename = file.path(out_dir, "TernTables_methods.docx"),
  open_doc         = FALSE,
  OR_col           = TRUE,
  insert_subheads  = TRUE,
  category_start   = c(
    "Patient Demographics"  = "Age (yr)",
    "Surgical Findings"     = "Colonic Obstruction",
    "Tumor Characteristics" = "Positive Lymph Nodes (n)",
    "Treatment Details"     = "Treatment Arm"
  )
)
tbl_2group

## ----ternG-3group, results = "hide"-------------------------------------------
tbl_3group <- ternG(
  data               = tern_colon,
  exclude_vars       = c("ID"),
  group_var          = "Treatment_Arm",
  group_order        = c("Observation", "Levamisole", "Levamisole + 5FU"),
  output_docx        = file.path(out_dir, "Tern_3_group.docx"),
  methods_filename   = file.path(out_dir, "TernTables_methods.docx"),
  open_doc           = FALSE,
  consider_normality = "ROBUST",
  post_hoc           = TRUE,
  category_start     = c(
    "Patient Demographics"  = "Age (yr)",
    "Surgical Findings"     = "Colonic Obstruction",
    "Tumor Characteristics" = "Positive Lymph Nodes (n)",
    "Outcomes"              = "Recurrence"
  )
)
tbl_3group

## ----ternG-fdr, eval = FALSE--------------------------------------------------
# tbl_fdr <- ternG(
#   data             = tern_colon,
#   exclude_vars     = c("ID"),
#   group_var        = "Recurrence",
#   p_adjust         = TRUE,
#   p_adjust_display = "both",   # show raw AND FDR-corrected P values
#   methods_doc      = FALSE
# )

## ----caption-example, eval = FALSE--------------------------------------------
# tbl_descriptive <- ternD(
#   data          = tern_colon,
#   exclude_vars  = c("ID"),
#   output_docx   = file.path(out_dir, "Tern_descriptive.docx"),
#   table_caption = "Table 1. Baseline patient characteristics."
# )

## ----footnote-example, eval = FALSE-------------------------------------------
# tbl_2group <- ternG(
#   data           = tern_colon,
#   exclude_vars   = c("ID"),
#   group_var      = "Recurrence",
#   OR_col         = TRUE,
#   output_docx    = file.path(out_dir, "Tern_2_group.docx"),
#   table_caption  = "Table 2. Characteristics by recurrence status.",
#   table_footnote = c(
#     "Abbreviations: OR, odds ratio; CI, confidence interval.",
#     "\u2020 P values from chi-square or Wilcoxon rank-sum test.",
#     "\u2021 ORs from unadjusted logistic regression."
#   )
# )

## ----methods-doc, eval = FALSE------------------------------------------------
# write_methods_doc(
#   tbl      = tbl_2group,
#   filename = file.path(out_dir, "Tern_methods.docx")
# )

